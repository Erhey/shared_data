
const logger = require('/opt/winston')
const { getFormattedBody } = require('/opt/aws-lambda-utile')
const { encryptToJson, decryptFromJson } = require('/opt/encrypt-decrypt-utile')

const moment = require('moment-timezone')
moment.tz.setDefault("Asia/Tokyo");

require('dotenv').config()

exports.handler = async (event) => {
    const mysql = require('mysql2/promise')
    let connectionRds = await mysql.createConnection({
        host: process.env.DB_HOST
        ,database: process.env.DB_NAME
        ,user: process.env.DB_USER
        ,password: process.env.DB_PASSWORD
        ,timezone: '+09:00'
    })
    try {
        
        let decrypted_formatted_body = JSON.parse(decryptFromJson(event.body, process.env.LAMBDA_PRIVATE_KEY, process.env.CBC_SECRET_KEY))

        // Initialization
        let responseObj = {}
        // Begin Transaction
        await connectionRds.beginTransaction();
        logger.info(`Request : ${JSON.stringify(decrypted_formatted_body)}`);
        let player_id = decrypted_formatted_body.id;
        logger.info(`player_id : ${player_id}`);
        responseObj.id = player_id;
        // Get Player Data
        let player = await getPlayerData(connectionRds, player_id);
        if(player) {
            responseObj.player_data = {}
            responseObj.player_data.collected_items = {}
            responseObj.player_data.collected_items.items_count = JSON.parse(player.items_count)
            responseObj.player_data.collected_items.unlocked_items = player.unlocked_items.split(',');
            responseObj.player_data.collected_items.unlocked_quests = player.unlocked_quests.split(',');
            responseObj.updated_date = player.updated_date;
        }
        if(!player) {
            responseObj.status = "fail"
            responseObj.message += " - User data not found - "
        }
        // Commit Changes
        await connectionRds.commit()
        // End Transaction
        await connectionRds.end()

        logger.info(`responseObj : ${JSON.stringify(responseObj)}`)
        return {
            statusCode: 200,
            body: encryptToJson(
                JSON.stringify(responseObj)
                ,process.env.UNITY_PUBLIC_KEY
                ,process.env.CBC_SECRET_KEY
            )
        }
    } catch (e) {
        console.log(e)
        await connectionRds.rollback()
        logger.error("Transaction rolledback successfully!")
        await connectionRds.end()
        logger.error("connectionRds End!")
        return {
            statusCode: 500,
            body: encryptToJson(JSON.stringify({
                    'status': 'error',
                    'message': e
                })
                ,process.env.UNITY_PUBLIC_KEY
                ,process.env.CBC_SECRET_KEY
            )
        }
    }
}
let getPlayerData = async (connectionRds, playerData) => {
    try {
        // SQL to get corresponding Mail Validation Information
        let sqlGetPlayerData = `SELECT
                                    p.id AS id,
                                    p.items_count AS items_count,
                                    p.unlocked_items AS unlocked_items,
                                    p.unlocked_quests AS unlocked_quests,
                                    p.updated_date AS updated_date 
                                FROM windy_the_adventurer.player p
                                WHERE p.id = ?`;
        logger.info(`SQL Get Player Data : ${sqlGetPlayerData}`)
        // Execute sql and Update user.
        const [result, fields] = await connectionRds.execute(sqlGetPlayerData, [playerData]);
        if(result.length > 0) {
            logger.info(`Player : ${JSON.stringify(result)}`)
            return result[0];
        } else {
            logger.info(`Player Not Found!`)
            return null;
        }
    } catch (e) {
        console.error("Error While processing getPlayerData function. Starting rollback. Error message" + e)
        throw e
    }
}